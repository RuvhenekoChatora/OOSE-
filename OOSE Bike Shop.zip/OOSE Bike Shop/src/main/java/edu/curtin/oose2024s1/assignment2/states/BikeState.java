package edu.curtin.oose2024s1.assignment2.states;
import edu.curtin.oose2024s1.assignment2.model.*;


/**State pattern interface class*/
public interface BikeState 
{
    /*state method implemented when a delivery occurs  */
    public String delivery(Bike bike,BikeShop bikeShop);
    /*state method implemented when a purchaseInStore occurs  */
    public String purchaseInStore(Bike bike,BikeShop bikeShop);
    /*state method implemented when a dropOff occurs  */
    public String dropOff(Bike bike,BikeShop bikeShop);
    /*state method implemented when a service occurs  */
    public  void service(Bike bike,BikeShop bikeShop);  
    /*state method implemented when a purchaseOnline occurs  */  
    public String purchaseOnline(Bike bike,BikeShop bikeShop);
    /*state method implemented when a pick occurs  */
    public String pick(Bike bike,BikeShop bikeShop);
}