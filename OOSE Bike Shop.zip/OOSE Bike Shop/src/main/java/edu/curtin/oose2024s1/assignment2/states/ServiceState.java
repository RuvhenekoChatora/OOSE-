package edu.curtin.oose2024s1.assignment2.states;
import edu.curtin.oose2024s1.assignment2.model.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/*concrete state class State: ServiceState*/
public class ServiceState implements BikeState 
{
    private static final Logger LOGGER = Logger.getLogger(ServiceState.class.getName());
    @Override
    public String pick(Bike bike,BikeShop bikeShop)
    {
        String result;

        if((bike.getMessage().equals("DROP-OFF")) && (bike.getTime()==0) && (bike.getEmail().equals(bike.getEmailForPick())))//for a case were a bike's time is now 0 but the stae of the bike is still service i.e it has not yet changed to awiting
        {
            
            result ="Still in Service";
            LOGGER.log(Level.WARNING, () -> "Still in Service");
        }
        else if((bike.getMessage().equals("DROP-OFF"))&& (bike.getEmail().equals(bike.getEmailForPick())))
        {
            result ="Still in Service";
            LOGGER.log(Level.WARNING, () -> "Still in Service");
            
        }
        else
        {
            result ="No Match";
            
        }

        return result;
    }

    @Override
    public void service(Bike bike,BikeShop bikeShop)
    {
                   
        int remainingTime = bike.getTime();
        
        if ((remainingTime>0)) 
        {
            remainingTime--;            
            bike.setTime(remainingTime);
        }
        else            
        { 
                
            bike.setState(new AwaitingPickUpState());
            LOGGER.log(Level.INFO, " Service is COMPLETE Bike changed state to awaiting pick up.");
            bikeShop.notifyObservers(bikeShop);
        }
        
        
    }

    @Override
    public String delivery(Bike bike,BikeShop bikeShop)
    {
        
        return null;
    }

    @Override
    public String purchaseInStore(Bike bike,BikeShop bikeShop)
    {
        
        return null;
    }
    @Override
    public String dropOff(Bike bike,BikeShop bikeShop)
    {
        return null;
    }
    @Override
    public String purchaseOnline(Bike bike,BikeShop bikeShop)
    {
        return null;
    }
    
}   