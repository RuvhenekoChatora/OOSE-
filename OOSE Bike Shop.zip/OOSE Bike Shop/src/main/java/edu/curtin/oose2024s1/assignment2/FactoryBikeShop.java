package edu.curtin.oose2024s1.assignment2;
import edu.curtin.oose2024s1.assignment2.model.MessageObserver;
import edu.curtin.oose2024s1.assignment2.view.*;

/*Factory calss that makes an oberver object that handles updates depending on the message from the simulation */
public class FactoryBikeShop
{
    private MessageObserver observer;

    

    public MessageObserver createObserver(String prefix)
    {
    
        if(prefix.equals("DELIVERY"))
        {
            observer = new Delivery();
        }
        else if(prefix.equals("DROP-OFF"))
        {
            observer = new Drop();
        }
        else if(prefix.equals("PICK-UP"))
        {
            observer = new Pick();
        }
        else if(prefix.equals("PAY"))
        {
            observer = new Pay();
        }
        else if(prefix.equals("PURCHASE-IN-STORE"))
        {
            observer = new PurchaseInStore();
        }
        else if(prefix.equals("PURCHASE-ONLINE"))
        {
            observer = new PurchaseOnline();
        }
        else if(prefix.equals("SERVICE-PAYMENT")) 
        {
            observer = new ServicePayment();
        }
        else if(prefix.equals("SERVICE"))
        {
            observer = new Service();
        }

        return observer;        

    }

 

    
}