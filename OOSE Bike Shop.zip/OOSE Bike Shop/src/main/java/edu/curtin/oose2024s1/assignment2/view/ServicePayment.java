package edu.curtin.oose2024s1.assignment2.view;
import edu.curtin.oose2024s1.assignment2.model.BikeShop;
import edu.curtin.oose2024s1.assignment2.model.MessageObserver;
import java.util.logging.Level;
import java.util.logging.Logger;


/* concrete observer class that handles and updates when a bike is being picked up after service
 message*/

public class ServicePayment implements MessageObserver
{
    private static final Logger LOGGER = Logger.getLogger(ServicePayment.class.getName());
    @Override
    public void update(BikeShop bikeShop) {
        
            LOGGER.log(Level.INFO, "servive payment update triggered");
            int currentCash =bikeShop.getCash();
            bikeShop.setCash((currentCash+100));
            
       
    }
    
}