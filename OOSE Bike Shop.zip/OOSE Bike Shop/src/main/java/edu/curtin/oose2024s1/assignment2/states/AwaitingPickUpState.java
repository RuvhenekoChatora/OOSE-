package edu.curtin.oose2024s1.assignment2.states;
import edu.curtin.oose2024s1.assignment2.model.*;
import edu.curtin.oose2024s1.assignment2.FactoryBikeShop;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/*concrete state class State: AwaitingPickUpState*/
public class AwaitingPickUpState implements BikeState {

    private static final Logger LOGGER = Logger.getLogger(AwaitingPickUpState.class.getName());

    @Override
    public String pick(Bike bike,BikeShop bikeShop)
    {
        String result;

        

        if((bike.getMessage().equals("PURCHASE-ONLINE")) && (bike.getEmail()).equals(bike.getEmailForPick()))
        {
            //change state
            bike.setState(new IdleState());
            LOGGER.log(Level.INFO, () -> "Bike state changing to idle state");
            bikeShop.notifyObservers(bikeShop);
            result = "Match";
            LOGGER.log(Level.INFO, "This is an online match.");
            
            

        }
        else if((bike.getMessage().equals("DROP-OFF")) && (bike.getTime()==0) && ((bike.getEmail()).equals(bike.getEmailForPick())))
        {
            //change state
            bike.setState(new IdleState());
            bikeShop.notifyObservers(bikeShop);

            int currentCash =bikeShop.getCash();
            bikeShop.setCash((currentCash+100));
           
            
            result ="Match";
            LOGGER.log(Level.INFO, "This is a DROP OFF match.");
        }
        else
        {
            result ="No Match"; 
            LOGGER.log(Level.INFO, "No match found.");
           
            
        }

        return result;
    }


    @Override
    public String delivery(Bike bike,BikeShop bikeShop)
    {
        
        return null;
    }
    @Override
    public String dropOff(Bike bike,BikeShop bikeShop)
    {
        return null;
    }
    @Override
    public String purchaseOnline(Bike bike,BikeShop bikeShop)
    {
        return null;
    }


    @Override
    public String purchaseInStore(Bike bike,BikeShop bikeShop)
    {
        
        return null;
    }
    @Override
    public void service(Bike bike,BikeShop bikeShop)
    {
        //ignored
    }
}    