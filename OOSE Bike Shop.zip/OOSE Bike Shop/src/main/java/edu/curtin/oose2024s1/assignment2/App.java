package edu.curtin.oose2024s1.assignment2;
import edu.curtin.oose2024s1.assignment2.bikeservicemanager.*;
import edu.curtin.oose2024s1.assignment2.bikeshopsetup.*;
import edu.curtin.oose2024s1.assignment2.employeemanager.*;
import edu.curtin.oose2024s1.assignment2.messagehandler.*;
import edu.curtin.oose2024s1.assignment2.statisticsmanager.*;
import edu.curtin.oose2024s1.assignment2.model.filehandling.*;
import edu.curtin.oose2024s1.assignment2.model.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;


public class App
{
    private static final Logger LOGGER = Logger.getLogger(App.class.getName());

    public static void main(String[] args)
    {
        // Initialize bike shop setup
        BikeShopSetup bikeShopSetup = new BikeShopSetup();
        BikeShop bikeShop = bikeShopSetup.initializeBikeShop();
        // Initialize file output for logging simulation results
        FileOutput fileOutput = new FileOutput("sim_results.txt");
        // Initialize message handler to process incoming messages
        MessageHandler messageHandler = new MessageHandler(bikeShop, fileOutput);
        // Initialize bike service manager to handle bike servicing
        BikeServiceManager bikeServiceManager = new BikeServiceManager(bikeShop);
        // Initialize employee manager to handle employee payments
        EmployeeManager employeeManager = new EmployeeManager(bikeShop);
        // Initialize statistics manager to display daily and overall statistics
        StatisticsManager statisticsManager = new StatisticsManager(bikeShop, fileOutput);

        BikeShopInput inp = new BikeShopInput();
        List<String> validMessages = new ArrayList<>();
        int totalInputs = 0;
        int totalFailures = 0;
        int days = 1;

        try
        {
            while (System.in.available() == 0)
            {
                System.out.println("---");
                String msg = inp.nextMessage();
                while (msg != null)
                {
                    //System.out.println(msg);
                    totalInputs++;
                    if (isValidMessage(msg))
                    {
                        validMessages.add(msg);
                    }
                    else
                    {
                        try
                        {
                            fileOutput.writeFailure("Invalid message(parsing error)");
                            totalFailures++;
                        }
                        catch (FileWritingException e)
                        {
                            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
                        }
                    }
                    msg = inp.nextMessage();
                }

                // Handle valid messages and perform daily operations
                messageHandler.handleMessages(validMessages);
                totalFailures += messageHandler.getTotalFailures();
                bikeServiceManager.serviceBikes();
                employeeManager.payEmployees(days);
                statisticsManager.displayStatistics(days);

                validMessages.clear();
                days++;
                // Pause simulation for a short period
                try
                {
                    Thread.sleep(1000);
                }
                catch (InterruptedException e)
                {
                    throw new AssertionError(e);
                }
            }
        }
        catch (IOException e)
        {
            LOGGER.log(Level.WARNING, "Error reading user input");
        }

        // Display overall statistics at the end
        statisticsManager.displayOverallStatistics(totalInputs, totalFailures);
    }


/**
     * Validates the message to ensure it conforms to expected formats.
     * 
     * @param message The message to validate.
     * @return true if the message is valid, false otherwise.
     */
    public static boolean isValidMessage(String message)
    {
        String[] validPrefixes = {"DELIVERY", "DROP-OFF", "PURCHASE-ONLINE", "PURCHASE-IN-STORE", "PICK-UP"};
        for (String prefix : validPrefixes)
        {
            if (message.startsWith(prefix))
            {
                if (prefix.equals("DELIVERY") || prefix.equals("PURCHASE-IN-STORE"))
                {
                    return true;
                }
                else
                {
                    int spaceIndex = message.indexOf(" ");
                    if (spaceIndex != -1 && message.substring(spaceIndex + 1).contains("@"))
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
