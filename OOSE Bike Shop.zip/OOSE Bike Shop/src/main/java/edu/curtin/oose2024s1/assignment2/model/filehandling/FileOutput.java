package edu.curtin.oose2024s1.assignment2.model.filehandling;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.FileWriter;
import java.io.IOException;


/*file ouput class that writes to both the terminal and the file*/
public class FileOutput {
    private static final Logger LOGGER = Logger.getLogger(FileOutput.class.getName());
    private String filePath;

    public FileOutput(String filePath) {
        this.filePath = filePath;
    }

    public void writeFailure(String message) throws FileWritingException {
        // Write to the terminal
        System.out.println("FAILURE: "+ message);
        
        // Write to the file
        try (FileWriter writer = new FileWriter(filePath, true)) {
            writer.write("FAILURE: " +message + "\n");
            writer.flush(); // Ensure immediate writing to the file
        }
        catch (IOException e) {
            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
            throw new FileWritingException("Failed to write failure message to file", e);
        }
    }
    public void writeOutput(String message) throws FileWritingException {
        // Write to the terminal
        System.out.println(message);
        
        // Write to the file
        try (FileWriter writer = new FileWriter(filePath, true)) {
            writer.write(message + "\n");
            writer.flush(); // Ensure immediate writing to the file
        }
        catch (IOException e) {
            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
            throw new FileWritingException("Failed to write failure message to file", e);
        }
    }

    
}