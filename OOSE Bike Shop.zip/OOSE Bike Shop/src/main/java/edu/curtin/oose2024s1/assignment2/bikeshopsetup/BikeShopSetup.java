package edu.curtin.oose2024s1.assignment2.bikeshopsetup;

import edu.curtin.oose2024s1.assignment2.model.*;
import edu.curtin.oose2024s1.assignment2.states.*;
import java.util.List;
import java.util.ArrayList;

/**A class to initialize the bike shop with bikes and manage its state. */
public class BikeShopSetup
{
    public BikeShop initializeBikeShop()
    {
        BikeShop bikeShop = new BikeShop();

        for (int i = 0; i < 50; i++)
        {
            Bike bike = new Bike(bikeShop, new AvailableState(), "none");
            bikeShop.addBikes(bike);
            bikeShop.addAvailableBikes(bike);
        }

        return bikeShop;
    }
}