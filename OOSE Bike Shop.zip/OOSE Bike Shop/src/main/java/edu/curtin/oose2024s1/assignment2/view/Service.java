package edu.curtin.oose2024s1.assignment2.view;
import edu.curtin.oose2024s1.assignment2.model.BikeShop;
import edu.curtin.oose2024s1.assignment2.model.MessageObserver;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/* concrete observer class that handles event where there is a bike in service*/

public class Service implements MessageObserver
{
    private static final Logger LOGGER = Logger.getLogger(Service.class.getName());
    @Override
    public void update(BikeShop bikeShop) 
    {
            LOGGER.log(Level.INFO, "service update triggered");
            int currentServiceCount =bikeShop.getServiceCount();
            bikeShop.setServiceCount((currentServiceCount-1));

            
            int currentAwaitingPickUpCount =bikeShop.getAwaitingPickUpCount();
            bikeShop.setAwaitingPickUpCount((currentAwaitingPickUpCount+1));

    }
    
}