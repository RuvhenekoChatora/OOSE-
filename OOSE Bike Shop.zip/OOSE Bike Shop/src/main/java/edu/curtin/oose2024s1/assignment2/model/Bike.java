package edu.curtin.oose2024s1.assignment2.model;
import edu.curtin.oose2024s1.assignment2.states.BikeState;
/**
 * 
 * This is the context class for the state  pattern. bike class models an instance of a bike
 */
public class Bike
{
    private BikeState state;
    private int time;
    private BikeShop bikeShop;
    private String email;
    private String emailForPick;
    private String message;
     

    //String prefix;

    // Constructor
    public Bike(BikeShop bikeShop,BikeState state,String email) 
    {
        this.bikeShop= bikeShop;
        this.state = state;
        this.time = 2;
        this.email=email;
    }
    // Setter method for the state
    public void setState(BikeState state) {
        this.state = state;
        
    }
    public BikeState getState() {
        return state;
        
    }
    // Setter method for the time
    public void setTime(int time) {
        this.time = time;
    }
    public int getTime() {
        return time;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public String getMessage() {
        return message;
    }
    public String getEmailForPick()
    {
        return emailForPick;
    }
    public void setEmailForPick(String email)
    {
        this.emailForPick = email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getEmail() {
        return email;
    }


    public String delivery()
    {
        return state.delivery(this,bikeShop);
    }
    public String purchaseInStore()
    {
        
        return state.purchaseInStore(this,bikeShop);
    }
    public String dropOff()
    {
        
        return state.dropOff(this,bikeShop);
    }
    public void service()
    {
        
        state.service(this,bikeShop);
    }
    public String purchaseOnline()
    {
        
        return state.purchaseOnline(this,bikeShop);
    }
    public String pick()
    {
        
        return state.pick(this,bikeShop);
    }
    



}    