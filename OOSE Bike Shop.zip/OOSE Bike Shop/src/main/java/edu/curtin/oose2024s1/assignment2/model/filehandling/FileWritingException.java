package edu.curtin.oose2024s1.assignment2.model.filehandling;

/**
 * An exception thrown when an error occurs during file writing.
 */
public class FileWritingException extends Exception {
    public FileWritingException(String msg) {
        super(msg);
    }

    public FileWritingException(String msg, Throwable cause) {
        super(msg, cause);
    }
}