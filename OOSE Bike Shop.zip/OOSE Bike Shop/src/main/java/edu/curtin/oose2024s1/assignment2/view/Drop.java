package edu.curtin.oose2024s1.assignment2.view;
import edu.curtin.oose2024s1.assignment2.model.BikeShop;
import edu.curtin.oose2024s1.assignment2.model.MessageObserver;
import java.util.logging.Level;
import java.util.logging.Logger;

/* concrete observer class that handles drop off message*/

public class Drop implements MessageObserver
{
    private static final Logger LOGGER = Logger.getLogger(Drop.class.getName());
    @Override
    public void update(BikeShop bikeShop) {
        
        
            LOGGER.log(Level.INFO, "Drop off  update triggered"); 
            int currentBikeCount =bikeShop.getBikeCount();
            bikeShop.setBikeCount((currentBikeCount+1));
            int currentServiceCount =bikeShop.getServiceCount();
            bikeShop.setServiceCount((currentServiceCount+1));

            
            
           
       
    }
    
}