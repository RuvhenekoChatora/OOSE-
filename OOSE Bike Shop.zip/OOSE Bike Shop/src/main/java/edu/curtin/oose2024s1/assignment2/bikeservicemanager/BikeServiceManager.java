package edu.curtin.oose2024s1.assignment2.bikeservicemanager;
import edu.curtin.oose2024s1.assignment2.*;
import edu.curtin.oose2024s1.assignment2.model.*;
import edu.curtin.oose2024s1.assignment2.states.*;
import edu.curtin.oose2024s1.assignment2.view.*;
import java.util.List;
import java.util.Iterator;

/**A class to manage the servicing of bikes. */
public class BikeServiceManager
{
    private BikeShop bikeShop;

    public BikeServiceManager(BikeShop bikeShop)
    {
        this.bikeShop = bikeShop;
    }

    public void serviceBikes()
    {
        List<Bike> serviceBikes = bikeShop.getServiceBikeList();
        Iterator<Bike> iterator = serviceBikes.iterator();

        while (iterator.hasNext())
        {
            Bike bike = iterator.next();
            FactoryBikeShop factoryBikeShop = new FactoryBikeShop();
            MessageObserver observer = factoryBikeShop.createObserver("SERVICE");
            bikeShop.addObserver(observer);
            bike.service();
            bikeShop.removeObserver(observer);

            if (bike.getTime() <= 0)
            {
                bikeShop.addAwaitingPickUpBikes(bike);
            }
        }
    }
}