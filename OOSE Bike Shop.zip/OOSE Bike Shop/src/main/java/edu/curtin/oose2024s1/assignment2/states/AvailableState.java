package edu.curtin.oose2024s1.assignment2.states;
import edu.curtin.oose2024s1.assignment2.model.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/*concrete state class State: AvailableState*/
public class AvailableState implements BikeState 
{
    private static final Logger LOGGER = Logger.getLogger(AvailableState.class.getName());
    @Override
    public String purchaseOnline(Bike bike,BikeShop bikeShop)
    {
        String result =null;
        Bike removedBike =null;
        if (bikeShop.getAvailableCount()>0)
        {

            bike.setState(new AwaitingPickUpState());
            LOGGER.log(Level.INFO, () -> "Bike state changing to awaiting pickup");
            bikeShop.notifyObservers(bikeShop);
            bike.setMessage("PURCHASE-ONLINE");
            //remove a bike from  the shop bikes list
            if (!(bikeShop.getAvailableBikeList().isEmpty())) 
            {
                removedBike =bikeShop.getAvailableBikeList().remove(0); // Remove the bike at index 0
                LOGGER.log(Level.INFO, () -> "Bike removed for online purchase: ");
            }
            bikeShop.getAwaitingPickUpBikeList().add(removedBike);
            
        }
        else
        {
            result="No bikes left (for a customer to purchase)"; 
            LOGGER.log(Level.WARNING, () -> "No bikes left (for a customer to purchase)");
        }
        return result;
    }

    
    @Override
    public String purchaseInStore(Bike bike,BikeShop bikeShop)
    {
        String result =null;
        if (bikeShop.getAvailableCount()>0)
        {
            bike.setState(new IdleState());
            LOGGER.log(Level.INFO, () -> "Bike state changing to idle pickup");
            bikeShop.notifyObservers(bikeShop);
            //remove a bike from  the shop bikes list
            if (!(bikeShop.getAvailableBikeList().isEmpty())) 
            {
                bikeShop.getAvailableBikeList().remove(0); // Remove the bike at index 0
                LOGGER.log(Level.INFO, "Bike removed for in-store purchase.");

            }
            if (!(bikeShop.getBikeList().isEmpty())) 
            {
                bikeShop.getBikeList().remove(0); // Remove the bike at index 0
                LOGGER.log(Level.INFO, "Bike removed from the shop's bike list.");
                
            }
            
        }
        else
        {
            result="No bikes left (for a customer to purchase)";
            LOGGER.log(Level.WARNING, () -> "No bikes left (for a customer to purchase)"); 
        }
        return result;
    }

    @Override
    public String delivery(Bike bike,BikeShop bikeShop)
    {
        return null;
    }  
    @Override
    public String dropOff(Bike bike,BikeShop bikeShop)
    {
        return null;
    }
    @Override
    public void service(Bike bike,BikeShop bikeShop)
    {
        //ignored
    }
    @Override
    public String pick(Bike bike,BikeShop bikeShop)
    {
        return null;
    }

}   