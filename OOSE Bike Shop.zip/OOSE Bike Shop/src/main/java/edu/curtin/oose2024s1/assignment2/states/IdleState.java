package edu.curtin.oose2024s1.assignment2.states;
import edu.curtin.oose2024s1.assignment2.model.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/*concrete state class State: IdleState*/
public class IdleState implements BikeState 
{
    private static final Logger LOGGER = Logger.getLogger(IdleState.class.getName());
    @Override
    public String delivery(Bike bike,BikeShop bikeShop)
    {
        String result =null;
        
        if ((bikeShop.getBikeCount()<=90)&& (bikeShop.getCash()>=10000))
        {
            bike.setState(new AvailableState());
            LOGGER.log(Level.INFO, "Bike state changed to available bikes.");
            bikeShop.notifyObservers(bikeShop);
            bikeShop.addBikes(bike);
            bikeShop.addAvailableBikes(bike);
            LOGGER.log(Level.INFO, "Bike delivered and added to available bikes.");
            
        }
        else
        {
            if((bikeShop.getCash()<10000))
            {
                result =" Not enough cash (for the shop to purchase new bikes)";
                LOGGER.log(Level.WARNING, () -> " Not enough cash (for the shop to purchase new bikes)");
            }
            else if((bikeShop.getBikeCount()>90))
            {
                result = " Not enough space (to store more bikes)";
                LOGGER.log(Level.WARNING, () -> " Not enough space (to store more bikes)");
            }
            else if((!(bikeShop.getCash()<10000))&&(!(bikeShop.getBikeCount()>90)))
            {
                result = " Not enough cash (for the shop to purchase new bikes) AND Not enough space (to store more bikes)" ;
                LOGGER.log(Level.WARNING, () -> " Not enough cash (for the shop to purchase new bikes) AND Not enough space (to store more bikes)");
            }
        }
        return result;
    }
    @Override
    public String dropOff(Bike bike,BikeShop bikeShop)
    {
        String result =null;
        
        if ((bikeShop.getBikeCount()<=99))
        {
            
            bike.setState(new ServiceState());
            bikeShop.notifyObservers(bikeShop);
            bike.setMessage("DROP-OFF");
            bikeShop.addBikes(bike);
            bikeShop.addServiceBikes(bike);
            LOGGER.log(Level.INFO, "Bike dropped off and added to service bikes.State changed to service state");
            
            
        }
        else
        {
            result = " Not enough space (to store more bikes for service)";
            LOGGER.log(Level.WARNING, () -> " Not enough space (to store more bikes for service)");
        }
        return result;
    }
     @Override
    public String purchaseInStore(Bike bike,BikeShop bikeShop)
    {
        return null;
    }
    @Override
    public synchronized void service(Bike bike,BikeShop bikeShop)
    {
        //ignored
    }
    @Override
    public String purchaseOnline(Bike bike,BikeShop bikeShop)
    {
        return null;
    }
    @Override
    public String pick(Bike bike,BikeShop bikeShop)
    {
        return null;
    }
}    