package edu.curtin.oose2024s1.assignment2.model;

/* interface class for the obersver pattern. Updates Bike shop when certain evernts occur*/
public interface MessageObserver 
{
    void update(BikeShop bikeShop);
}