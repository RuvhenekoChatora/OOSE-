package edu.curtin.oose2024s1.assignment2.view;
import edu.curtin.oose2024s1.assignment2.model.BikeShop;
import edu.curtin.oose2024s1.assignment2.model.MessageObserver;
import java.util.logging.Level;
import java.util.logging.Logger;

/* concrete observer class that handles delivery message*/
public class Delivery implements MessageObserver
{
    private static final Logger LOGGER = Logger.getLogger(Delivery.class.getName());
    @Override
    public void update(BikeShop bikeShop) 
    {
        LOGGER.log(Level.INFO, "Delivery update triggered");
        int currentBikeCount =bikeShop.getBikeCount();
        bikeShop.setBikeCount((currentBikeCount+10));            
        int currentCash =bikeShop.getCash();
        bikeShop.setCash((currentCash-5000));
        int currentAvailable =bikeShop.getAvailableCount();
        bikeShop.setAvailableCount((currentAvailable+10));
    }
    
}