package edu.curtin.oose2024s1.assignment2.statisticsmanager;
import edu.curtin.oose2024s1.assignment2.*;
import edu.curtin.oose2024s1.assignment2.model.*;
import edu.curtin.oose2024s1.assignment2.model.filehandling.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**A class to handle statistics and reporting */
public class StatisticsManager
{
    private static final Logger LOGGER = Logger.getLogger(StatisticsManager.class.getName());
    private BikeShop bikeShop;
    private FileOutput fileOutput;

    public StatisticsManager(BikeShop bikeShop, FileOutput fileOutput)
    {
        this.bikeShop = bikeShop;
        this.fileOutput = fileOutput;
    }

    public void displayStatistics(int days)
    {
        try
        {
            System.out.println("Number of days elapsed = " + days);

            int totalCash = bikeShop.getCash();
            fileOutput.writeOutput("Total cash in the bank account = " + totalCash);

            int available = bikeShop.getAvailableCount();
            fileOutput.writeOutput("Number of bikes available for purchase = " + available);

            int serviceCount = bikeShop.getServiceCount();
            fileOutput.writeOutput("Number of bikes being serviced = " + serviceCount);

            int awaitingPickUpCount = bikeShop.getAwaitingPickUpCount();
            fileOutput.writeOutput("Number of bikes awaiting pick-up = " + awaitingPickUpCount);
        }
        catch (FileWritingException e)
        {
            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
        }
    }

    public void displayOverallStatistics(int totalInputs, int totalFailures)
    {
        try
        {
            fileOutput.writeOutput("\nThe total number of input messages is = " + totalInputs);
            fileOutput.writeOutput("The total number of failures is = " + totalFailures);
        }
        catch (FileWritingException e)
        {
            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
        }
    }
}