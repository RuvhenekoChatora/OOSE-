package edu.curtin.oose2024s1.assignment2.view;
import edu.curtin.oose2024s1.assignment2.model.BikeShop;
import edu.curtin.oose2024s1.assignment2.model.MessageObserver;
import java.util.logging.Level;
import java.util.logging.Logger;

/* concrete observer class that handles pick message*/
public class Pick implements MessageObserver
{
    private static final Logger LOGGER = Logger.getLogger(Pick.class.getName());
    @Override
    public void update(BikeShop bikeShop) {
        
            LOGGER.log(Level.INFO, "pick update triggered");
            int currentBikeCount =bikeShop.getBikeCount();
            bikeShop.setBikeCount((currentBikeCount-1));            
            
            int currentAwaitingPickUp =bikeShop.getAwaitingPickUpCount();
            bikeShop.setAwaitingPickUpCount((currentAwaitingPickUp-1));

    }
    
}
