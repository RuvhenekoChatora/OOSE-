package edu.curtin.oose2024s1.assignment2.model;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 
 * This is the subject for the observer pattern.This moels an unstance of teh bike shop
 */
public class BikeShop
{
    
    private int cash;
    private int bikeCount;    
    private int serviceCount;
    private int awaitingPickUpCount;
    private int availableCount;
    private List<String> dropOffEmails = new ArrayList<>();
    private List<String> awaitingPickUp = new ArrayList<>();
    private List<Bike> bikes =new ArrayList<>(); //store all bikes 
    private List<Bike> serviceBikes =new ArrayList<>();
    private List<Bike> availableBikes =new ArrayList<>();
    private List<Bike> awaitingPickUpBikes =new ArrayList<>();
    private List<MessageObserver> observers=new ArrayList<>();
    

    public BikeShop()
    {
        bikeCount = 50; 
        cash= 15000;
        availableCount =50;
        
    }

    public void addBikes(Bike bike)
    {
        bikes.add(bike);
    }

    public List<Bike> getBikeList()
    {
        return bikes;
    }

    public void addServiceBikes(Bike bike)
    {
        serviceBikes.add(bike);
    }

    public List<Bike> getServiceBikeList()
    {
        return serviceBikes;
    }
    public void addAvailableBikes(Bike bike)
    {
        availableBikes.add(bike);
    }

    public List<Bike> getAvailableBikeList()
    {
        return availableBikes;
    }
    public void addAwaitingPickUpBikes(Bike bike)
    {
        awaitingPickUpBikes.add(bike);
    }

    public List<Bike> getAwaitingPickUpBikeList()
    {
        return awaitingPickUpBikes;
    }

    public void setCash(int cash)
    {
        this.cash=cash;
    }
    public void setBikeCount(int bikeCount)
    {
        this.bikeCount =bikeCount ;
    }
    public  void setAwaitingPickUpCount(int awaitingPickUpCount)
    {
        this.awaitingPickUpCount =awaitingPickUpCount;
    }
    public void setAvailableCount(int availableCount)
    {
        this.availableCount=availableCount;
    }
    public void setServiceCount(int serviceCount)
    {
        this.serviceCount=serviceCount;
    }
    public void setDropOffEmails(List<String> dropOffEmails)
    {
        this.dropOffEmails=dropOffEmails;
    }
    public void setAwaitingPickUp(List<String> awaitingPickUp)
    {
        this.awaitingPickUp=awaitingPickUp;
    }
    public int getCash()
    {
        return cash;
    }
    public int getBikeCount()
    {
        return bikeCount ;
    }
    public int getAwaitingPickUpCount()
    {
        return awaitingPickUpCount;
    }
    public int getAvailableCount()
    {
        return availableCount;
    }
    public int getServiceCount()
    {
        return serviceCount;
    }
    public List<String> getDropOffEmails()
    {
        return dropOffEmails;
    }
    public List<String> getAwaitingPickUp()
    {
        return awaitingPickUp;
    }

    public void addObserver(MessageObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(MessageObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers(BikeShop bikeShop) {
        for (MessageObserver observer : observers) {
            observer.update(bikeShop);
        }
    }
}