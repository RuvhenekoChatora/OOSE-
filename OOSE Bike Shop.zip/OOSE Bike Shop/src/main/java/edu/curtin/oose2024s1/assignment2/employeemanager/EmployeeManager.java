package edu.curtin.oose2024s1.assignment2.employeemanager;
import edu.curtin.oose2024s1.assignment2.*;
import edu.curtin.oose2024s1.assignment2.model.*;
import edu.curtin.oose2024s1.assignment2.view.*;

/**A class to handle employee-related tasks like paying salaries */
public class EmployeeManager
{
    private BikeShop bikeShop;

    public EmployeeManager(BikeShop bikeShop)
    {
        this.bikeShop = bikeShop;
    }

    public void payEmployees(int day)
    {
        if (day % 7 == 0 && day != 0)
        {
            FactoryBikeShop factoryBikeShop = new FactoryBikeShop();
            MessageObserver observer = factoryBikeShop.createObserver("PAY");
            bikeShop.addObserver(observer);
            bikeShop.notifyObservers(bikeShop);
            bikeShop.removeObserver(observer);
        }
    }
}