package edu.curtin.oose2024s1.assignment2.messagehandler;
import edu.curtin.oose2024s1.assignment2.*;
import edu.curtin.oose2024s1.assignment2.model.*;
import edu.curtin.oose2024s1.assignment2.model.filehandling.*;
import edu.curtin.oose2024s1.assignment2.states.*;
import edu.curtin.oose2024s1.assignment2.view.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/*Contains classes related to handling input simulation messages*/
public class MessageHandler
{
    private static final Logger LOGGER = Logger.getLogger(MessageHandler.class.getName());
    private BikeShop bikeShop;
    private FileOutput fileOutput;
    private int totalFailures;

    public MessageHandler(BikeShop bikeShop, FileOutput fileOutput)
    {
        this.bikeShop = bikeShop;
        this.fileOutput = fileOutput;
        this.totalFailures = 0;
    }

    /**
     * Returns the total number of failures encountered.
     * @return Total number of failures.
     */
    public int getTotalFailures()
    {
        return totalFailures;
    }

    /**
     * Processes a list of valid messages, delegating each to the appropriate handler.
     * @param validMessages List of messages to handle.
     */

    public void handleMessages(List<String> validMessages)
    {
        Iterator<String> iterator = validMessages.iterator();

        while (iterator.hasNext())
        {
            String message = iterator.next();
            String[] parts = message.split(" ");

            switch (parts[0])
            {
                case "DROP-OFF":
                    if (parts.length >= 2)
                    {
                        handleDropOff(parts[1]);
                    }
                    break;
                case "PURCHASE-ONLINE":
                    if (parts.length >= 2)
                    {
                        handlePurchaseOnline(parts[1]);
                    }
                    break;
                case "DELIVERY":
                    handleDelivery();
                    break;
                case "PURCHASE-IN-STORE":
                    handlePurchaseInStore();
                    break;
                case "PICK-UP":
                    if (parts.length >= 2)
                    {
                        handlePickUp(parts[1]);
                    }
                    break;
                default:
                    LOGGER.log(Level.WARNING, () ->"Unknown message type: " + parts[0]);
                    break;
            }
            iterator.remove();
        }
    }

    /**
     * Handles the delivery action by creating a bike and attempting delivery.
     * @throws FileWritingException If an error occurs during file writing.
     */
    private void handleDelivery() 
    {
        try
        {
            Bike bike = new Bike(bikeShop, new IdleState(), "none");
            FactoryBikeShop factoryBikeShop = new FactoryBikeShop();
            MessageObserver observer = factoryBikeShop.createObserver("DELIVERY");
            bikeShop.addObserver(observer);
            String message = bike.delivery();
            fileOutput.writeOutput("DELIVERY attempt");
            if (message != null)
            {
                fileOutput.writeFailure(message);
                totalFailures++;
            }
            bikeShop.removeObserver(observer);
        }
        catch (FileWritingException e)
        {
            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
        }
    }

    /**
     * Handles in-store purchases by attempting to sell the first available bike.
     * @throws FileWritingException If an error occurs during file writing.
     */
    private void handlePurchaseInStore() 
    {
        try
        {
            
            if (bikeShop.getAvailableBikeList().isEmpty())
            {
                fileOutput.writeFailure("No bikes left (for a customer to purchase)");
                totalFailures++;
            }
            else
            {
                Bike firstAvailableBike = bikeShop.getAvailableBikeList().get(0);
                FactoryBikeShop factoryBikeShop = new FactoryBikeShop();
                MessageObserver observer = factoryBikeShop.createObserver("PURCHASE-IN-STORE");
                bikeShop.addObserver(observer);
                firstAvailableBike.purchaseInStore();
                fileOutput.writeOutput("PURCHASE-IN-STORE attempt");
                bikeShop.removeObserver(observer);
            }
        }
        catch (FileWritingException e)
        {
            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
        }
    }

    /**
     * Handles the drop-off action by creating a bike with the given email and attempting drop-off.
     * @param email The email associated with the drop-off.
     * @throws FileWritingException If an error occurs during file writing.
     */
    private void handleDropOff(String email)
    {
        try
        {
            Bike bike = new Bike(bikeShop, new IdleState(), email);
            FactoryBikeShop factoryBikeShop = new FactoryBikeShop();
            MessageObserver observer = factoryBikeShop.createObserver("DROP-OFF");
            bikeShop.addObserver(observer);
            String message = bike.dropOff();
            fileOutput.writeOutput("DROP-OFF attempt");
            if (message != null)
            {
                fileOutput.writeFailure(message);
                totalFailures++;
            }
            bikeShop.removeObserver(observer);
        }
        catch (FileWritingException e)
        {
            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
        }
    }

    /**
     * Handles online purchases by attempting to sell the first available bike.
     * @param email The email associated with the online purchase.
     * @throws FileWritingException If an error occurs during file writing.
     */
    private void handlePurchaseOnline(String email)
    {
        try
        {
            if (bikeShop.getAvailableBikeList().isEmpty())
            {
                fileOutput.writeFailure("No bikes left (for a customer to purchase)");
                totalFailures++;
            }
            else
            {
                Bike firstAvailableBike = bikeShop.getAvailableBikeList().get(0);
                firstAvailableBike.setEmail(email);
                FactoryBikeShop factoryBikeShop = new FactoryBikeShop();
                MessageObserver observer = factoryBikeShop.createObserver("PURCHASE-ONLINE");
                bikeShop.addObserver(observer);
                firstAvailableBike.purchaseOnline();
                fileOutput.writeOutput("PURCHASE-ONLINE attempt");
                bikeShop.removeObserver(observer);
            }
            
        }
        catch (FileWritingException e)
        {
            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
        }
    }

    private void handlePickUp(String email)
    {
        try
        {
            List<String> msgs = new ArrayList<>();
            fileOutput.writeOutput("PICK-UP attempt");

            for (Bike bike : bikeShop.getBikeList())
            {
                FactoryBikeShop factoryBikeShop = new FactoryBikeShop();
                MessageObserver observer = factoryBikeShop.createObserver("PICK-UP");
                bikeShop.addObserver(observer);
                bike.setEmailForPick(email);
                String message = bike.pick();

                if (message != null)
                {
                    msgs.add(message);
                }

                bikeShop.removeObserver(observer);
            }

            processPickUpMessages(msgs);
        }
        catch (FileWritingException e)
        {
            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
        }
    }

    /**
     * Processes the messages resulting from the pick-up action.
     * @param msgs List of messages to process.
     * @throws FileWritingException If an error occurs during file writing.
     */
    private void processPickUpMessages(List<String> msgs)
    {
        int totalElements = msgs.size();
        int serviceCount = 0;
        int noMatchCount = 0;

        for (String msg : msgs)
        {
            if (msg.equals("Still in Service"))
            {
                serviceCount++;
            }
            else if (msg.equals("No Match"))
            {
                noMatchCount++;
            }
        }

        try
        {
            if (noMatchCount == totalElements)
            {
                fileOutput.writeFailure("No bike matching customer email (for pick-up)");
                totalFailures++;
            }
            else if (serviceCount > 0)
            {
                for (int i = 0; i < serviceCount; i++)
                {
                    fileOutput.writeFailure("Bike not ready (still in service)");
                    totalFailures++;
                }
            }
        }
        catch (FileWritingException e)
        {
            LOGGER.log(Level.SEVERE, () -> "Error writing to file: " + e.getMessage());
        }
    }
}